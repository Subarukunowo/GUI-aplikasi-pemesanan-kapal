import javax.swing.*;

public class Jadwal {
    private JButton PemesananBtn;
    private JButton JadwalBtn;
    private JButton RiwayatBtn;
    private JButton ProfilBtn;
    private JLabel fieldNamaKapal;
    private JLabel fieldHasilNamaKapal;
    private JLabel fieldJamBerangkat;
    private JLabel fieldTanggalBerangkat;
    private JLabel fieldTujuan;
    private JLabel fieldHasilJamBerangkat;
    private JLabel fieldHasilTanggalBerangkat;
    private JLabel fieldHasilTujuan;
    private JTextField tfSearch;
    private JButton SearchBtn;
    private JLabel judulJadwalKapal;
}
